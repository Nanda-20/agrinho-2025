let isCity = false; // Controla a troca entre cidade e campo
let transitionSpeed = 0.05; // Velocidade de transição

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(255); // Fundo branco

  // Alterna entre campo e cidade
  if (isCity) {
    drawCity();
  } else {
    drawField();
  }
  
  // Verifica se a transição deve acontecer
  if (frameCount % 120 == 0) { // Troca de cenário a cada 2 segundos
    isCity = !isCity;
  }
}

// Função para desenhar o campo
function drawField() {
  // Céu e terra
  background(135, 206, 235); // Céu azul
  fill(34, 139, 34); // Cor verde para o campo
  rect(0, height / 2, width, height / 2); // Desenha o chão

  // Plantações (linhas de plantas)
  drawPlantation();

  // Árvores
  drawTree(100, height / 2 + 30);
  drawTree(300, height / 2 + 50);
  drawTree(500, height / 2 + 20);

  // Sol
  fill(255, 223, 0);
  noStroke();
  ellipse(width - 100, 100, 80, 80);
}

// Função para desenhar a plantação no campo
function drawPlantation() {
  stroke(34, 139, 34); // Cor das plantas (verde)
  strokeWeight(3); // Espessura das linhas de plantação

  // Criando linhas de plantação
  for (let i = 0; i < width; i += 50) {
    line(i, height / 2 + 20, i, height - 10); // Linhas verticais de plantação
  }
  
  // Criando pequenas plantas nas linhas
  for (let i = 50; i < width; i += 100) {
    for (let j = height / 2 + 30; j < height - 20; j += 40) {
      drawPlant(i, j);
    }
  }
}

// Função para desenhar uma planta (simples)
function drawPlant(x, y) {
  fill(0, 128, 0); // Cor das folhas
  noStroke();
  ellipse(x, y, 10, 10); // Folhas
  
  fill(139, 69, 19); // Cor do caule
  rect(x - 2, y + 5, 4, 10); // Caule
}

// Função para desenhar a cidade
function drawCity() {
  // Céu e prédios
  background(200, 220, 255); // Céu claro da cidade
  fill(150, 150, 150); // Cor cinza para os prédios
  rect(0, height / 2, width, height / 2); // Chão

  // Edifícios
  drawBuilding(100, height / 2 - 200, 100, 200);
  drawBuilding(250, height / 2 - 150, 120, 150);
  drawBuilding(450, height / 2 - 250, 90, 250);
  drawBuilding(650, height / 2 - 180, 130, 180);

  // Carros na estrada
  drawCar(50, height / 2 + 50);
  drawCar(300, height / 2 + 100);
  drawCar(500, height / 2 + 70);
}

// Função para desenhar uma árvore
function drawTree(x, y) {
  fill(139, 69, 19); // Tronco
  rect(x - 10, y, 20, 40);
  
  fill(34, 139, 34); // Folhagem
  ellipse(x, y - 20, 50, 50);
}

// Função para desenhar um prédio
function drawBuilding(x, y, w, h) {
  fill(169, 169, 169); // Cor do prédio
  rect(x, y, w, h);

  // Janelas
  fill(255); // Cor das janelas
  for (let i = 0; i < w / 20; i++) {
    for (let j = 0; j < h / 30; j++) {
      rect(x + i * 20 + 5, y + j * 30 + 5, 15, 20);
    }
  }
}

// Função para desenhar um carro
function drawCar(x, y) {
  fill(255, 0, 0); // Cor do carro
  rect(x, y, 60, 30); // Corpo do carro

  // Rodas
  fill(0);
  ellipse(x + 15, y + 30, 20, 20);
  ellipse(x + 45, y + 30, 20, 20);
}
